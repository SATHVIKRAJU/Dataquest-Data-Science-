import pandas
def load_data():
   df=pandas.read_csv("hn_stories.csv")
   df.columns = ["submission_time", "upvotes", "url", "headline"]
   return df
    #pass
if __name__=="__main__":
   data=load_data()
