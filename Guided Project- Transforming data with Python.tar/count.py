import read
df= read.load_data()
word_counts={}
string_full=""
head_list =df["headline"].tolist()
for head in head_list:
    string_full+=(str(head) + '')
    string_full=string_full.lower()
    for word in string_full:
        if word not in word_counts:
           word_counts[word]=1
        else:
            word_counts[word]+=1
            
print(word_)