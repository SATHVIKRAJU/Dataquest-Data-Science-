import pandas as pd
import sqlite3

conn = sqlite3.connect('factbook.db')

df = pd.read_sql_query('SELECT SUM(area_land), SUM(area_water) FROM facts WHERE area_land != "";', con = conn)

print(df['SUM(area_land)'] / df['SUM(area_water)'])