import pandas as pd
import sqlite3
import math

conn=sqlite3.connect("factbook.db")
df=pd.read_sql_query("select * from facts ",con=conn)
df=df.dropna(axis=0)
df=df[(df["area_land"]>0) & (df["population"]>0)]
def n_funct(x):
    var_1=x["population"]*math.e**((x["population_growth"]/100)*35)
df["pop_2050"]=df.apply(lambda row: n_funct(row) ,axis =1)
b = df.sort(['pop_2050'], ascending = [False])
b = b['name'].iloc[0:9]
print(b)